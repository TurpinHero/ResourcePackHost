import os
from PIL import Image
folder = os.getcwd()

type = "stone"
tool = "shovel"

hostFile="examples/" +tool+"_host.png"
raiserFile="examples/" +tool+"_raiser.png"
shaperFile="examples/" +tool+"_shaper.png"
wayfinderFile="examples/" +tool+"_wayfinder.png"
orFile=type+"_" + tool +".png"
im = Image.open(hostFile, 'r')
im2 = Image.open(raiserFile, 'r')
im3 = Image.open(shaperFile, 'r')
im4 = Image.open(wayfinderFile, 'r')
img = Image.open(orFile, 'r')

alpha = im.convert('RGBA').split()[-1]
img2 = img.convert('RGBA')
img2.putalpha(alpha)
img2.save(orFile.replace(".png", "_host.png"))

alpha = im2.convert('RGBA').split()[-1]
img2 = img.convert('RGBA')
img2.putalpha(alpha)
img2.save(orFile.replace(".png", "_raiser.png"))

alpha = im3.convert('RGBA').split()[-1]
img2 = img.convert('RGBA')
img2.putalpha(alpha)
img2.save(orFile.replace(".png", "_shaper.png"))

alpha = im4.convert('RGBA').split()[-1]
img2 = img.convert('RGBA')
img2.putalpha(alpha)
img2.save(orFile.replace(".png", "_wayfinder.png"))
print("done")
